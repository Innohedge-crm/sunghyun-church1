﻿param([string]$Uri)

function Show-Msg($text) {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($text, "PPT 합치기 - 찬양인도자앱 Series 1 (ppt+)") | Out-Null
}

# PowerPoint COM의 RGB 색상은 r + g*256 + b*65536 형태의 정수 하나로 넘겨야 한다
function New-RgbColor([int]$r, [int]$g, [int]$b) {
    return $r + ($g * 256) + ($b * 65536)
}

# 파일 경로에서 화면에 보여줄 제목만 뽑아낸다 - 확장자를 떼고, 파일명 끝에
# 흔히 붙는 "_Wide", "_Wide (1)" 같은 화면비 표시는 실제 곡 제목이 아니므로
# 구분 슬라이드에는 보이지 않게 지운다
function Get-DisplayTitle([string]$path) {
    $name = [System.IO.Path]::GetFileNameWithoutExtension($path)
    $name = $name -replace '_Wide(\s*\(\d+\))?\s*$', ''
    return $name.Trim()
}

# 여러 개의 PPT 파일(.ppt 옛 형식과 .pptx가 섞여 있어도 상관없음)을 순서대로
# 이어붙이면서, 각 곡 앞에 제목 구분 슬라이드를 넣어 하나의 .pptx 파일로
# 저장한다. ("합치기 실행" 버튼에서 pptmerge:merge:<...> 로 호출됨 -
# <...>는 {"files":[...전체경로들...],"output":"저장할 전체경로"} 를
# UTF-8 → Base64로 인코딩한 문자열)
function Merge-Presentations {
    param([string[]]$Files, [string]$OutputPath)

    if (-not $Files -or $Files.Count -eq 0) { throw "합칠 파일이 전달되지 않았습니다." }
    foreach ($f in $Files) {
        if (-not (Test-Path -LiteralPath $f)) { throw "파일을 찾을 수 없습니다: $f" }
    }

    # 합치기 전에 PowerPoint가 이미 실행 중이었는지 확인해 둔다 - 이미 켜져
    # 있던 것이면(사용자가 다른 작업 중일 수 있으므로) 끝나고 나서 강제로
    # 끄지 않고, 내가 새로 켠 경우에만 끝나고 나서 정리한다.
    $wasAlreadyRunning = $true
    try {
        $null = [Runtime.InteropServices.Marshal]::GetActiveObject("PowerPoint.Application")
    } catch {
        $wasAlreadyRunning = $false
    }

    $ppt = New-Object -ComObject PowerPoint.Application
    $pres = $null
    try {
        # PowerPoint COM 속성들은 True/False가 아니라 정해진 숫자(열거형) 값을
        # 요구합니다 - 일부 시스템에서는 $true를 그냥 넘기면 "Boolean을
        # MsoTriState로 캐스팅할 수 없습니다" 오류가 나기 때문에, 항상
        # 숫자 값으로 직접 지정합니다.
        $ppt.Visible = -1             # msoTrue
        $ppt.DisplayAlerts = 1        # ppAlertsNone - 자동화 중 확인창이 떠서 멈추는 것 방지
        try { $ppt.AutomationSecurity = 3 } catch { } # msoAutomationSecurityForceDisable - 합치기에는 매크로가 필요 없으므로 항상 끈 상태로 연다

        $pres = $ppt.Presentations.Add()   # WithWindow 인자를 생략 - 기본값(표시함)으로 새 프레젠테이션 생성
        foreach ($f in $Files) {
            $title = Get-DisplayTitle $f
            $slideW = $pres.PageSetup.SlideWidth
            $slideH = $pres.PageSetup.SlideHeight

            # 곡마다 앞에 제목 구분 슬라이드를 넣는다 - 짙은 남색 배경에 흰
            # 글씨를 화면 가운데에 굵게 (레이아웃 19 = ppLayoutTitleOnly)
            $addIndex = $pres.Slides.Count + 1
            $titleSlide = $pres.Slides.Add($addIndex, 19)

            try {
                $titleSlide.FollowMasterBackground = 0   # msoFalse - 이 슬라이드만 배경을 따로 지정
                $titleSlide.Background.Fill.Solid()
                $titleSlide.Background.Fill.ForeColor.RGB = New-RgbColor 24 35 64
            } catch { }

            $titleShape = $null
            try { $titleShape = $titleSlide.Shapes.Title } catch { $titleShape = $null }
            if (-not $titleShape) {
                # 이 레이아웃에 제목 틀이 없는 예외적인 경우를 대비해, 텍스트
                # 상자를 직접 만들어서라도 제목이 항상 보이도록 한다
                $titleShape = $titleSlide.Shapes.AddTextbox(1, 0, 0, $slideW, $slideH)
            }

            $titleShape.Left = 0
            $titleShape.Top = 0
            $titleShape.Width = $slideW
            $titleShape.Height = $slideH

            $tr = $titleShape.TextFrame.TextRange
            $tr.Text = $title
            $tr.Font.Size = 44
            $tr.Font.Bold = -1                        # msoTrue
            $tr.Font.Color.RGB = New-RgbColor 255 255 255
            $tr.ParagraphFormat.Alignment = 2          # ppAlignCenter
            try { $titleShape.TextFrame2.VerticalAnchor = 3 } catch { }  # msoAnchorMiddle - 화면 세로 가운데 정렬

            $insertAfter = $pres.Slides.Count
            $pres.Slides.InsertFromFile($f, $insertAfter)
        }

        $outDir = Split-Path -Parent $OutputPath
        if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
            New-Item -ItemType Directory -Path $outDir -Force | Out-Null
        }

        $pres.SaveAs($OutputPath, 24)  # ppSaveAsOpenXMLPresentation (.pptx)
        Show-Msg "합치기가 완료되었습니다:`n$OutputPath"
    } finally {
        if ($pres) {
            try { $pres.Close() } catch { }
            [Runtime.InteropServices.Marshal]::ReleaseComObject($pres) | Out-Null
        }
        if (-not $wasAlreadyRunning) {
            try { $ppt.Quit() } catch { }
        }
        [Runtime.InteropServices.Marshal]::ReleaseComObject($ppt) | Out-Null
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}


# ── 안전 점검 ──────────────────────────────────────────────
# pptmerge: 링크는 어느 웹페이지에서나 부를 수 있으므로, 찬양콘티메이커가 실제로
# 보내는 형식만 받는다.
#  · 합칠 파일: 이 PC 드라이브(C:\ 같은)의 .ppt / .pptx 만
#  · 저장 위치: 이 PC 드라이브의 「PPT 합본」 폴더 안 .pptx 만
#  · 요청 파일: 「PPT 합본」 폴더 안 「_합치기요청.json」 만
$OutFolderName = 'PPT 합본'
$ReqFileName   = '_합치기요청.json'
function Test-LocalPath([string]$p) {
    return ($p -match '^[A-Za-z]:\\') -and ($p -notmatch '\\\.\.(\\|$)')
}
function Assert-MergeRequest($files, [string]$output) {
    if (-not $files) { throw "합칠 파일이 전달되지 않았습니다." }
    foreach ($f in @($files)) {
        if (-not (Test-LocalPath $f) -or $f -notmatch '\.pptx?$') { throw "합칠 수 없는 파일 위치입니다: $f" }
    }
    if (-not (Test-LocalPath $output) -or $output -notmatch '\.pptx$') { throw "저장 위치가 올바르지 않습니다: $output" }
    if ((Split-Path -Leaf (Split-Path -Parent $output)) -ne $OutFolderName) { throw "결과는 「${OutFolderName}」 폴더에만 저장할 수 있습니다: $output" }
}

try {
    # Windows sometimes appends a trailing slash to custom-protocol links; strip it.
    $Uri = $Uri.TrimEnd('/')
    $Uri = [System.Uri]::UnescapeDataString($Uri)

    # Expected form:
    #   pptmerge:merge:<base64 JSON>   (여러 PPT를 제목 슬라이드와 함께 하나로 합치기)
    $body = $Uri -replace '^pptmerge:/*', ''

    # 콘티메이커 v2: 곡이 많아 링크에 다 담기지 않으면, 요청 내용을 PPT 합본 폴더의
    # _합치기요청.json 파일에 써 두고 그 파일 위치만 링크로 보낸다.
    if ($body -like 'mergefile:*') {
        $reqPath = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($body.Substring(10)))
        if (-not (Test-LocalPath $reqPath) -or (Split-Path -Leaf $reqPath) -ne $ReqFileName -or (Split-Path -Leaf (Split-Path -Parent $reqPath)) -ne $OutFolderName) { throw "합치기 요청 파일 위치가 올바르지 않습니다: $reqPath" }
        if (-not (Test-Path -LiteralPath $reqPath)) { throw "합치기 요청 파일을 찾을 수 없습니다: $reqPath" }
        $jsonText = Get-Content -LiteralPath $reqPath -Raw -Encoding UTF8
        $data = $jsonText | ConvertFrom-Json
        try { Remove-Item -LiteralPath $reqPath -Force } catch { }
        Assert-MergeRequest $data.files $data.output
        Merge-Presentations -Files $data.files -OutputPath $data.output
        exit
    }

    if ($body -like 'merge:*') {
        $payload = $body.Substring(6)  # 'merge:' 다음부터
        $jsonText = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payload))
        $data = $jsonText | ConvertFrom-Json
        Assert-MergeRequest $data.files $data.output
        Merge-Presentations -Files $data.files -OutputPath $data.output
        exit
    }

    Show-Msg "이해할 수 없는 요청입니다.`n`n받은 링크: $Uri"
}
catch {
    Show-Msg "실행 중 오류가 발생했습니다:`n`n$($_.Exception.Message)`n`n전달받은 링크: $Uri"
}
