@echo off
rem PPT merge helper installer (current user only, no admin rights needed)
cd /d "%~dp0"
if not exist "C:\PPTMerge" mkdir "C:\PPTMerge"
copy /Y "launch.ps1" "C:\PPTMerge\launch.ps1" >nul
if errorlevel 1 goto fail
reg import "register.reg"
if errorlevel 1 goto fail
echo.
echo  Done. C:\PPTMerge\launch.ps1 installed.
echo.
pause
exit /b 0
:fail
echo.
echo  Install failed. Please unzip the folder first and run again.
echo.
pause
exit /b 1
